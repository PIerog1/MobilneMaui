﻿using System;
using Microsoft.Maui.Controls;

namespace Mobilne6._3
{
    public partial class MainPage : ContentPage
    {
        int licznik;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnPlusClicked(object sender, EventArgs e)
        {
            licznik++;
            if (EtykietaLiczby != null)
                EtykietaLiczby.Text = licznik.ToString();
        }

        private void OnMinusClicked(object sender, EventArgs e)
        {
            if (licznik > 0)
            {
                licznik--;
            }
            if (EtykietaLiczby != null)
                EtykietaLiczby.Text = licznik.ToString();
        }

        private void OnZerujClicked(object sender, EventArgs e)
        {
            licznik = 0;
            if (EtykietaLiczby != null)
                EtykietaLiczby.Text = licznik.ToString();
        }
    }
}
