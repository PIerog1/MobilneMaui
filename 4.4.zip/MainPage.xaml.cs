﻿namespace Mobilne4._3
{
    public partial class MainPage : ContentPage
    {
        

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSendClicked(object? sender, EventArgs e)
        {
            string forma;
            string oczekiwania = Oczekiwania.Text;
            string imie = Imie.Text;
            string nazwisko = Nazwisko.Text;
            string wiedza;
            string certyfikat;
            if (string.IsNullOrWhiteSpace(imie) || string.IsNullOrWhiteSpace(nazwisko))
            {
                DisplayAlertAsync("Niepoprawne Dane", "Uzupełnij dane", "OK");
                return;
            }
            else
            {
                if (FormaStacjonarna.IsChecked)
                {
                    forma = "Stacjonarna";
                }
                else if (FormaOnline.IsChecked)
                {
                    forma = "Online";
                }
                else if (FormaHybrydowa.IsChecked)
                {
                    forma = "Hybrydowa";
                }
                else
                {
                    forma = "Nie wybrano";
                }
                if (Wiedza.IsChecked == true)
                {
                    wiedza = "Posiada podstawowa wiedze";
                }
                else
                {
                    wiedza = "Nie posiada podstawowej wiedzy";
                }
                if (Certyfikat.IsToggled == true)
                {
                    certyfikat = "Chce otrzymac certyfikat";
                }
                else
                    certyfikat = "Nie chce otrzymac certyfikatu";
                DisplayAlertAsync("Formularz Wyslany", $"Imie: {imie} Nazwisko: {nazwisko} Pole wiedzy: {wiedza}, Certyfikat: {certyfikat},Forma kursu: {forma}, Oczekiwania: {oczekiwania}", "OK");
            }
        }
    }
}
