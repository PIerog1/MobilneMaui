﻿namespace Mobilne4._2
{
    public partial class MainPage : ContentPage
    {
       

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnSendClicked(object? sender, EventArgs e)
        {
            string imie = Imie.Text;
            string nazwisko = Nazwisko.Text;
            string wiedza;
            string certyfikat;
            if(Wiedza.IsChecked == true)
            {
                wiedza = "Posiada podstawowa wiedze";
            }
            else
            {
                wiedza = "Nie posiada podstawowej wiedzy";
            }
            if (Certyfikat.IsToggled == true)
            {
                certyfikat = "Chce otrzymac certyfikat";
            }
            else
                certyfikat = "Nie chce otrzymac certyfikatu";
            DisplayAlertAsync("Formularz Wyslany",$"Imie: {imie} Nazwisko: {nazwisko} Pole wiedzy: {wiedza}, Certyfikat: {certyfikat}","OK");
        }
    }
}
