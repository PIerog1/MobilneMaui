﻿using System;
using Microsoft.Maui.Controls;

namespace Mobilne5._3
{
    public partial class MainPage : ContentPage
    {
        string sala;
        public MainPage()
        {
            InitializeComponent();
            LiczbaOsobStepper.Value = 1;
            LiczbaOsob.Text = $"Liczba osób: {(int)LiczbaOsobStepper.Value}";
        }

        private void OnSalaChanged(object? sender, EventArgs e)
        {
             sala = SalePicker.SelectedItem.ToString();

        }

        private void OnLiczbaOsobChanged(object? sender, ValueChangedEventArgs e)
        {
            LiczbaOsob.Text = $"Liczba osób: {(int)e.NewValue}";
        }

        private void OnDataChanged(object sender, DateChangedEventArgs e)
        {
            
        }

        private void OnZarezerwujClicked(object? sender, EventArgs e)
        {
            if(SalePicker.SelectedItem != null)
            {
                DisplayAlertAsync("Rezerwacja",$"Rezerwacja Sali: {sala},  {LiczbaOsob.Text}, Data: {DataPicker.Date}","ok");
            }
            else
            {
                DisplayAlertAsync("Błąd", "Nie wybrano sali", "ok");
            }
        }
    }
}
