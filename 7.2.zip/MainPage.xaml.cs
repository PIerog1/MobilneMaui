﻿namespace Mobilne7._2
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCornSilkClicked(object? sender, EventArgs e)
        {
            Color cornsilk = Color.FromArgb("#FFF8DC");
            this.BackgroundColor = cornsilk;
            Etykieta.Text = "Aktualny kolor: Cornsilk(#FFF8DC)";
        }

        private void OnPeruClicked(object? sender, EventArgs e)
        {
            Color peru = Color.FromArgb("#CD853F");
            this.BackgroundColor = peru;
            Etykieta.Text = "Aktualny kolor: Peru(#CD853F)";
        }

        
    }
}
