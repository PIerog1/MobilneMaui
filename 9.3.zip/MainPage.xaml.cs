﻿using System.Collections.ObjectModel;

namespace Mobilne9._3
{
    public partial class MainPage : ContentPage
    {
        private ObservableCollection<string> zadania = new ObservableCollection<string>();
        public MainPage()
        {
            InitializeComponent();
            
            WidokListy.ItemsSource = zadania;
            WidokListy.SelectionMode = SelectionMode.Single;        
        }

        private void OnDodajClicked(object? sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(Entry1.Text))
            {
                zadania.Add(Entry1.Text);
                Entry1.Text = string.Empty;
                EtykietaLista2.Text = $"Aktualnie na liscie: {zadania.Count}";
            }
            
        }
        private void UsunZaznaczoneClicked(object? sender, EventArgs e)
        {
            if (WidokListy.SelectedItem is string wybrany)
            {
                zadania.Remove(wybrany);
                WidokListy.SelectedItem = null;
                EtykietaLista2.Text = $"Aktualnie na liscie: {zadania.Count}";
            }
        }
    }
}
