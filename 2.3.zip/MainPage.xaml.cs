﻿namespace Mobilne2._3
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCounterClicked(object? sender, EventArgs e)
        {
            count++;

            if (count >= 1)
                Powitanie.Text = "Pozdrowienia z miasta: " + Miasto.Text;
            else
                Powitanie.Text = Powitanie.Text;
        }
    }
}
