﻿namespace Mobilne3._2
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnCounterClicked(object? sender, EventArgs e)
        {
            
        }
        private void OnWyczyscClicked(object? sender, EventArgs e)
        {
           
            if (string.IsNullOrWhiteSpace(Email.Text) || (string.IsNullOrWhiteSpace(Telefon.Text)))
            {
                PanelKontaktowy.Text = "Wpisz  dane";
            }
            else
            {
                count--;
                if(count < 1)
                {
                    Email.Text = default;
                    Telefon.Text = default;
                    PanelKontaktowy.Text = "Panel Kontaktowy";
                }
            }
        }
    }
}
