﻿namespace Mobilne8._3
{
    public partial class MainPage : ContentPage
    {
        

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnObliczClicked(object? sender, EventArgs e)
        {
            string szerokosc = SzerokoscEntry.Text;
            string wysokosc = WysokoscEntry.Text;
            bool sukces = double.TryParse(szerokosc, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double szerokosc2);
            bool sukces2 = double.TryParse(wysokosc, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out double wysokosc2);
            if(sukces && sukces2)
            {
                if(szerokosc2 > 0 && wysokosc2 > 0)
                {
                    double iloczyn = szerokosc2 * wysokosc2;
                    PoleProstokata.Text = $"Pole Prostokąta wynosi: {iloczyn}"; 
                }
            }
            else
            {
                DisplayAlert("Bład","Błedne dane","Ok");
            }
        }
        private async void OnWyczyscClicked(object? sender,EventArgs e)
        {
            bool potwierdzenie = await DisplayAlert("Czyszczenie", "Czy wyczyscic?", "Tak", "Nie");

            if (potwierdzenie)
            {
                SzerokoscEntry.Text = "";
                WysokoscEntry.Text = "";
                PoleProstokata.Text = "Pole Prostokąta:";
            }
        }
    }
}
