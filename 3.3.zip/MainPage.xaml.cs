﻿namespace Mobilne3._3
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();
        }

        private void BtnZloz_Clicked(object sender, EventArgs e)
        {
            string produkt = EntryProdukt.Text?.Trim() ?? "";
            string ilosc = EntryIlosc.Text?.Trim() ?? "";
            string adres = EntryAdres.Text?.Trim() ?? "";

            if (string.IsNullOrEmpty(produkt) ||
                string.IsNullOrEmpty(ilosc) ||
                string.IsNullOrEmpty(adres))
            {
                DisplayAlert("Błąd", "Uzupełnij wszystkie pola", "OK");
                return;
            }

            string podsumowanie = $"Produkt: {produkt}, ilość: {ilosc}, adres: {adres}";
            DisplayAlert("Zamówienie", podsumowanie, "OK");
        }
   
    }
}
