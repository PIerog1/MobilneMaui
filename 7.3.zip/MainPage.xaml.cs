﻿namespace Mobilne7._3
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
        }

        private void Suwak_ValueChanged(object? sender, EventArgs e)
        {
          int r = (int)Suwak1.Value;
          int g = (int)Suwak2.Value;
          int b = (int)Suwak3.Value;
          this.BackgroundColor = Color.FromRgb(r, g, b);

            string hex1 = r.ToString("X2");
            string hex2 = g.ToString("X2");
            string hex3 = b.ToString("X2");
            Etykieta.Text = $"R: {hex1}, G: {hex2}, B: {hex3}";
        }
    }
}
