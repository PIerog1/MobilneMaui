﻿using System.Collections.ObjectModel;


namespace Mobilne9._2
{
    public partial class MainPage : ContentPage
    {
        private ObservableCollection<string> zadania = new ObservableCollection<string>();

        public MainPage()
        {
            InitializeComponent();
            WidokListy.ItemsSource = zadania;
        }

        private void OnDodajClicked(object? sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(Entry1.Text))
            {
                zadania.Add(Entry1.Text);
                Entry1.Text = string.Empty;
            }
        }
    }
}
