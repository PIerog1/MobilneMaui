﻿namespace Mobilne8._2
{
    public partial class MainPage : ContentPage
    {
        

        public MainPage()
        {
            InitializeComponent();
        }

        private async void OnSprawdzWiekClicked(object? sender, EventArgs e)
        {
            string tekst = wiekEntry.Text;
            bool sukces = int.TryParse(wiekEntry.Text, out int wiek);
            if (sukces)
            {
                if(wiek >= 1 && wiek <= 120)
                {
                    wiekLabel.Text = $"Twój wiek to: {wiek} lat.";
                }
                else
                {
                    await DisplayAlert("Błąd", "Wiek musi być w przedziale od 1 do 120 lat.", "OK");
                }
            }
            else
            {
                await DisplayAlert("Błąd","Wiek musi byc liczba","OK");
            }
        }
    }
}
