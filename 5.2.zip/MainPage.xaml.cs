﻿namespace Mobilne5._2
{
    public partial class MainPage : ContentPage
    {

        public MainPage()
        {
            InitializeComponent();
            SliderOcena.Value = 3;
        }

        private void OnValueChanged(object? sender, EventArgs e)
        {
            int ilosc = (int)SliderOcena.Value;
            EtykietaOcena.Text = $"Ocena: {ilosc:F1}";
        }
    }
}
